"""Installed Ubuntu Lumos companion: website binding, setup progress, CAN repair.

Preparation serves a small bootstrap API, then execs the SDK's isolated Python
on the same port. No controller is created by installation, setup or detection.
"""
import argparse
import html
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
import signal
from pathlib import Path
import subprocess
import sys
import threading
import time
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, build_opener

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from runtime.ubuntu_runtime import normalize_origin, read_config
from runtime.lumos_can import can_devices, device_identity
from tools import start_lumos_local as launcher

PORT = 18766
VERSION = '1.0.32'
SERVICE = 'star-arm-lumos-companion'
CAN_HELPER = '/usr/libexec/star-arm-lumos-can'


def publisher_origin():
    value = read_config(ROOT / 'website.json').get('origin')
    return normalize_origin(value) if value else None


class Preparation:
    def __init__(self, ready=False):
        self.stage = 'ready' if ready else 'preparing'
        self.message = 'Lumos 组件已就绪' if ready else '正在准备 Lumos SDK，首次需要联网；请保留网页等待。'
        self.lock = threading.Lock()
        self.thread = None
        self.python = None

    def snapshot(self):
        return {'stage': self.stage, 'message': self.message}

    def start(self, server):
        with self.lock:
            if self.stage == 'ready' or self.thread and self.thread.is_alive():
                return
            self.stage = 'preparing'
            self.message = '正在准备 Lumos SDK，首次需要联网；安装记录保存在本机。'
            self.thread = threading.Thread(target=self._prepare, args=(server,), daemon=True)
            self.thread.start()

    def _prepare(self, server):
        try:
            # System dependencies are installed by the .deb, not by a hidden sudo prompt.
            python, _ = launcher.prepare_environment(launcher.environment_directory())
            self.python = python
            self.message = '环境已准备，正在启动本地控制服务…'
            server.shutdown()
        except Exception as error:
            self.stage = 'failed'
            self.message = f'环境准备失败：{error}。请按具体错误处理后点击重试；已有文件会保留。'
            print(self.message, flush=True)


class CompanionHandlerMixin:
    """Only the publisher bound into the installed package can use Lumos APIs."""
    def _path(self):
        return urlsplit(self.path).path

    def _origin_ok(self):
        origin = self.headers.get('Origin')
        host = self.headers.get('Host', '').lower()
        return not origin or origin == f'http://{host}' or bool(self.server.publisher and origin == self.server.publisher)

    def _valid_host(self):
        port = self.server.server_port
        return (self.client_address[0] in ('127.0.0.1', '::1') and
                self.headers.get('Host', '').lower() in (f'127.0.0.1:{port}', f'localhost:{port}', f'[::1]:{port}'))

    def _public_health(self):
        if self._path() != '/api/v1/health':
            return False
        origin = self.headers.get('Origin')
        try:
            return not origin or normalize_origin(origin) == origin
        except (ValueError, TypeError):
            return False

    def _gate(self, mutation=False):
        if not self._valid_host():
            self._json(403, {'error': {'code': 'invalid_host', 'message': '本机组件请求地址无效'}})
            return False
        if not (self._origin_ok() or not mutation and self._public_health()):
            self._json(403, {'error': {'code': 'website_not_authorized',
                                     'message': '组件绑定的是其他网站，请从当前网站重新下载安装组件'}})
            return False
        if mutation and self.headers.get_content_type() != 'application/json':
            self._json(400, {'error': {'code': 'invalid_request', 'message': '请求需要 application/json'}})
            return False
        return True

    def end_headers(self):
        origin = self.headers.get('Origin')
        if self._valid_host() and origin and (self._origin_ok() or self._public_health()):
            self.send_header('Access-Control-Allow-Origin', origin)
            self.send_header('Vary', 'Origin')
            self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

    def do_OPTIONS(self):
        if not self._gate():
            return
        self.send_response(204)
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Content-Length', '0')
        self.end_headers()

    def _require_local_lumos(self, mutation=False):
        # Host and origin were checked before dispatch. Keep the JSON guard in
        # the original control handler; source-launch mode retains its own policy.
        from ai_service.domain import DomainError
        if not self._valid_host() or not self._origin_ok():
            raise DomainError('当前网站未授权使用 Lumos', 'lumos_origin_denied')
        if mutation and self.headers.get_content_type() != 'application/json':
            raise DomainError('请求需要 application/json', 'invalid_request')

    def do_GET(self):
        if not self._gate():
            return
        path = self._path()
        if path == '/api/v1/health':
            return self._json(200, {'service': SERVICE, 'version': VERSION, 'status': 'ok',
                                    'authorized': self._origin_ok(), 'platform': 'linux',
                                    'setup': self.server.preparation.snapshot()})
        if path == '/api/v1/lumos/setup/status':
            return self._json(200, self.server.preparation.snapshot())
        if path == '/api/v1/lumos/devices':
            try:
                return self._json(200, {'items': can_devices()})
            except (OSError, ValueError, subprocess.SubprocessError) as error:
                return self._json(400, {'error': {'code': 'can_detection_failed', 'message': f'无法检测 CAN：{error}'}})
        if path == '/':
            site = html.escape(self.server.publisher or '', quote=True)
            body = ('<!doctype html><meta charset="utf-8"><title>Lumos 本地组件</title>'
                    '<h1>Lumos 本地组件正在运行</h1><p>请返回安装组件的网站继续连接。</p>'
                    f'<a href="{site}">返回网站</a>').encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('X-Frame-Options', 'DENY')
            self.end_headers()
            return self.wfile.write(body)
        if path == '/api/v1/lumos/status' and self.server.preparation.stage == 'ready':
            return super().do_GET()
        self._json(404, {'error': {'code': 'not_found', 'message': '组件未就绪或接口不存在'}})

    def do_POST(self):
        if not self._gate(mutation=True):
            return
        # Drain and bound rejected/handled requests too, to return readable errors.
        path = self._path()
        if path in ('/api/v1/lumos/setup/retry', '/api/v1/lumos/configure-can'):
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= 4096:
                    raise ValueError('请求大小无效')
                body = json.loads(self.rfile.read(length))
                if not isinstance(body, dict):
                    raise ValueError('请求需要 JSON 对象')
                if path.endswith('/retry'):
                    self.server.preparation.start(self.server)
                    return self._json(200, self.server.preparation.snapshot())
                if self.server.preparation.stage != 'ready':
                    raise ValueError('请等待组件环境准备完成')
                if body.get('confirmed') is not True:
                    raise ValueError('请确认所选 USB-CAN 已用于这台 Lumos')
                interface = body.get('interface')
                device_identity(interface)
                runtime = self.server.lumos
                # Share the control operation lock: no concurrent connect can
                # acquire the interface while the system authorization is open.
                if not self.server.setup_lock.acquire(blocking=False):
                    raise ValueError('另一个连接或配置操作正在进行，请等待完成')
                try:
                    with runtime._operation_lock:
                        state = runtime.snapshot()
                        if any(state.get(key) for key in ('session_id', 'connecting', 'cleanup_pending', 'cleanup_failed')):
                            raise ValueError('请先停止并断开 Lumos，再配置 CAN')
                        result = subprocess.run(['/usr/bin/pkexec', '--disable-internal-agent', CAN_HELPER,
                                                 'configure', interface], capture_output=True, text=True,
                                                check=False, timeout=120)
                        if result.returncode:
                            raise ValueError((result.stdout or result.stderr).strip()[-1500:] or '系统授权未完成，请重试')
                finally:
                    self.server.setup_lock.release()
                return self._json(200, {'items': can_devices(), 'message': 'CAN 已配置为 1 Mbps，并已保存设备配置'})
            except (OSError, ValueError, subprocess.SubprocessError) as error:
                return self._json(400, {'error': {'code': 'lumos_setup_failed', 'message': str(error)}})
        if self.server.preparation.stage == 'ready' and (path.startswith('/api/v1/lumos/') or path == '/api/v1/emergency-stop'):
            if path != '/api/v1/lumos/connect':
                return super().do_POST()
            if not self.server.setup_lock.acquire(blocking=False):
                self.close_connection = True
                return self._json(409, {'error': {'code': 'lumos_setup_busy', 'message': '正在配置 CAN 或处理另一个操作，请完成后重试'}})
            try:
                return super().do_POST()
            finally:
                self.server.setup_lock.release()
        self._json(503, {'error': {'code': 'lumos_preparing', 'message': self.server.preparation.message}})


class BootstrapHandler(CompanionHandlerMixin, BaseHTTPRequestHandler):
    def _json(self, status, value):
        body = json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def create_companion_server(address, directory, *, ready=False, publisher=None, lumos=None):
    if ready:
        from ai_service.app import Handler, create_server
        class HandlerClass(CompanionHandlerMixin, Handler):
            pass
        server = create_server(address, directory, ROOT / 'runtime/Browser_SDK', data_dir_explicit=True, lumos=lumos)
        server.RequestHandlerClass = HandlerClass
    else:
        server = ThreadingHTTPServer(address, BootstrapHandler)
        server.daemon_threads = True
    server.publisher = publisher
    server.preparation = Preparation(ready)
    server.setup_lock = threading.Lock()
    return server


def health():
    try:
        with build_opener(ProxyHandler({})).open(f'http://127.0.0.1:{PORT}/api/v1/health', timeout=1) as response:
            value = json.load(response)
            return value if value.get('service') == SERVICE else None
    except (OSError, ValueError):
        return None


def state_directory():
    base = Path(os.environ.get('XDG_DATA_HOME', str(Path.home() / '.local/share')))
    return base / 'star-arm-102/lumos/companion'


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--background', action='store_true')
    parser.add_argument('--serve', action='store_true')
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--port', type=int, default=PORT, help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    launcher.validate_platform()
    directory = state_directory()
    directory.mkdir(parents=True, exist_ok=True)
    if not args.serve:
        if health():
            return 0
        # The installed package uses a supervised per-user service exclusively,
        # so upgrades/removal can always stop its exact process gracefully.
        try:
            subprocess.run(['/usr/bin/systemctl', '--user', 'daemon-reload'], capture_output=True, timeout=5, check=False)
            subprocess.run(['/usr/bin/systemctl', '--user', 'reset-failed', 'star-arm-lumos.service'], capture_output=True, timeout=5, check=False)
            started = subprocess.run(['/usr/bin/systemctl', '--user', 'start', '--no-block', 'star-arm-lumos.service'],
                                     capture_output=True, timeout=5, check=False).returncode == 0
        except (OSError, subprocess.SubprocessError):
            started = False
        if not started:
            raise RuntimeError('无法启动 Ubuntu 用户后台服务，请在正常桌面登录后打开“Lumos 机械臂连接助手”重试。')
        if not args.background:
            import tkinter.messagebox
            tkinter.messagebox.showinfo('Lumos 本地组件', '组件正在后台运行，请返回网站查看准备进度。')
        return 0
    # Re-exec preserves the current PID (and systemd supervision).
    log = (directory / 'runtime.log').open('ab', buffering=0)
    os.dup2(log.fileno(), 1)
    os.dup2(log.fileno(), 2)
    publisher = publisher_origin()
    environment = launcher.environment_directory()
    if args.worker:
        if Path(sys.prefix).resolve() != (environment / 'venv').resolve():
            raise RuntimeError('Lumos 必须使用隔离环境启动')
        os.environ['STAR_ARM_LUMOS_SDK_ROOT'] = str(environment / 'startouch_sdk')
    server = create_companion_server(('127.0.0.1', args.port), launcher.default_data_directory(),
                                     ready=args.worker, publisher=publisher)
    if not args.worker:
        server.preparation.start(server)
    stopping = threading.Event()
    def stop(signum, frame):
        stopping.set()
        threading.Thread(target=server.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, stop)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 0
    finally:
        server.server_close()
    if server.preparation.python and not stopping.is_set():
        python = server.preparation.python
        env = {**launcher.clean_environment(), 'PYTHONUNBUFFERED': '1'}
        os.execve(str(python), [str(python), str(Path(__file__)), '--serve', '--worker', '--port', str(args.port)], env)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
